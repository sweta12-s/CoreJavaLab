package com.studentmanagemnetsystem;

public @interface Test {

}
